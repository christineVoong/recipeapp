import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
//import 'package:intl/intl_browser.dart';


class InitialQuestions extends StatefulWidget {
  //modifier to associate string with class - dont have to create a whole new object to get the id
  static String id = 'initial_questions';

  @override
  _InitialQuestionsState createState() => _InitialQuestionsState();
}

class _InitialQuestionsState extends State<InitialQuestions> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(
                    children: <Widget>[
                      Flexible(
                          child: Container(
                            padding: EdgeInsets.all(10),
                            child: Text('Before we begin',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 30.0,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          )
                      ),
                    ]
                ),
                Flexible(
                    child: Container(
                      padding: EdgeInsets.all(10),
                      child: Text('Answer a few questions to get to know you a little better so we can show you relevant recipes right off the bat',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    )
                ),
                ]),
        ));
  }}

  class _QuestionsState extends State<Questions>{
    final _formKey = GlobalKey<FormBuilderState>();

    int _selectedRestriction = 0;
    List<DropdownMenuItem<int>> restrictionList = []



    @override
    Widget build(BuildContext context) {
      return FormBuilder(
          key: _formKey,
          child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    RaisedButton(
                        child: Text("Submit"),
                        onPressed: (){
                          if (_formKey.currentState.saveAndValidate()){
                            print(_formKey.currentState.value);
                          }
                        }
                    )
                  ],
                )
              ],))

      )
    throw UnimplementedError();
  }
  }