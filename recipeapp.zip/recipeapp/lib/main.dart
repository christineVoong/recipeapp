import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:recipeapp/Screens/initial_questions.dart';
import 'Screens/welcome_screen.dart';
import 'Screens/login_screen.dart';
import 'Screens/registration_screen.dart';
import 'Screens/home_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(recipeApp());
}

class recipeApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        initialRoute: WelcomeScreen.id,
        routes: {
          WelcomeScreen.id: (context) => WelcomeScreen(),
          LoginScreen.id: (context) => LoginScreen(),
          RegistrationScreen.id: (context) => RegistrationScreen(),
          InitialQuestions.id: (context) => InitialQuestions(),
          HomeScreen.id: (context) => HomeScreen(),

    }
    );
  }
}